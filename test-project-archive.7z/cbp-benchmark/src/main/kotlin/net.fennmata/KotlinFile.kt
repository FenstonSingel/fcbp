package net.fennmata

fun main() {
    Thread {
        while (true)
            Unit
    }.start()
}