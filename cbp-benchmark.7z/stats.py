from os import listdir
from os.path import isfile, join
import numpy as np
import scipy.stats as st

results_dir = "results"
for file in [join(results_dir, file_path) for file_path in listdir(results_dir) if isfile(join(results_dir, file_path))]:
    with open(file, 'r') as input:
        data = [float(line.rstrip().split()[-1]) for line in input]
    mean = np.mean(data)
    interval = st.t.interval(0.95, len(data)-1, loc=mean, scale=st.sem(data))
    print("{}: {} +- {}".format(file, mean, (interval[1] - interval[0]) / 2))
