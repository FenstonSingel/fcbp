package net.fennmata;

import java.util.stream.Stream;

public class InstrumentationTests implements Runnable {

    private static final int foo = 4;
    private static int hoo = 0;

    @Override
    public void run() {
        try {
            System.out.println("new tests!");
            for (int j = 0; j < 4; j++) {
                Thread.sleep(500L);
                System.out.println(String.format("foo == %d, hoo == %d", foo, hoo));
                Stream.of(1).map(i -> i + 1).map(i -> i + 2).findFirst();
                hoo++;
            }
        } catch (Exception e) {
            // ignored
        }
    }

    public static void log() {
        System.out.println("Instrumented stuff!");
    }

}
