package net.fennmata

fun main(args: Array<String>) {
    Thread {
        while (true) {
            val l = listOf(3).map { it + 1 }
        }
    }.start()
}