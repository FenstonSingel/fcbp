package net.fennmata;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Benchmark {

    public static void main(String[] args) throws IOException {
//        List<BenchmarkSettings> settingsForBPHCC = Arrays.asList(
//                new BenchmarkSettings(1e4, 1000),
//                new BenchmarkSettings(1e6, 1000),
//                new BenchmarkSettings(1e8, 1000)
//        );
//        for (BenchmarkSettings settings : settingsForBPHCC) { testBPHCC(settings); }

//        List<BenchmarkSettings> settingsForCBP = Arrays.asList(
//                new BenchmarkSettings(1e4, 50),
//                new BenchmarkSettings(1e6, 50)
//        );
//        for (BenchmarkSettings settings : settingsForCBP) { testCBP(settings); }

        runCBPEndlessly();
    }

    private static class BenchmarkSettings {
        public long loopLength;
        public long seriesLength;

        public BenchmarkSettings(double inLoopLength, long inSeriesLength) {
            loopLength = (long) inLoopLength;
            seriesLength = inSeriesLength;
        }
    }

    private static void testBPHCC(BenchmarkSettings settings) throws IOException {
        String resultFilePath = String.format(
                "results/bphcc-%d-loop-%d-series.txt",
                settings.loopLength, settings.seriesLength
        );
        long finalSeriesLength = settings.seriesLength + warmupPeriod;
        try (BufferedWriter resultWriter = new BufferedWriter(new FileWriter(resultFilePath))) {
            for (long experimentIndex = 0; experimentIndex < finalSeriesLength; ++experimentIndex) {
                long experimentStartTime = System.nanoTime();
                for (long index = 0; index <= settings.loopLength; ++index) {
                    if (index == settings.loopLength) {
                        int foo = 2 + 2;
                    }
                }
            }
        }
    }

    private static void testCBP(BenchmarkSettings settings) throws IOException {
        String resultFilePath = String.format(
                "results/cbp-%d-loop-%d-series.txt",
                settings.loopLength, settings.seriesLength
        );
        long finalSeriesLength = settings.seriesLength + warmupPeriod;
        try (BufferedWriter resultWriter = new BufferedWriter(new FileWriter(resultFilePath))) {
            for (long experimentIndex = 0; experimentIndex < finalSeriesLength; ++experimentIndex) {
                long experimentStartTime = System.nanoTime();
                for (long index = 0; index <= settings.loopLength; ++index) {
                    int foo = 2 + 2;
                }
            }
        }
    }

    private static void runCBPEndlessly() {
        while (true) {
            long experimentStartTime = System.nanoTime();
            for (long index = 0; index <= 1_000_000; ++index) {
                int foo = 2 + 2;
            }
        }
    }

    private static String recordResult(
            long duration, BufferedWriter resultWriter, long experimentIndex
    ) throws IOException {
        String result = String.format("%d | %f", duration, duration / 1e9);
        if (experimentIndex >= warmupPeriod) {
            resultWriter.write(result);
            resultWriter.newLine();
        }
        return result;
    }

    private static final long warmupPeriod = 2;

}
