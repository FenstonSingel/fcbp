import re
import numpy as np
import scipy.stats as st

files = [
    "results/bphcc-10000-loop-1000-series.txt",
    "results/bphcc-1000000-loop-1000-series.txt",
    "results/bphcc-100000000-loop-1000-series.txt",
    "results/cbp-10000-loop-50-series.txt",
    "results/cbp-1000000-loop-50-series.txt"
]

for file in files:
    with open(file, 'r') as input:
        data = [float(line.rstrip().split()[-1]) for line in input]
    mean = np.mean(data)
    interval = st.t.interval(0.95, len(data)-1, loc=mean, scale=st.sem(data))
    print("{}: {} +- {}".format(file, mean, (interval[1] - interval[0]) / 2))

